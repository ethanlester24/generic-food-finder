// frontend/src/App.js
import { useState } from "react";

function App() {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState([]);
  const [brand, setBrand] = useState("");
  const [generic, setGeneric] = useState("");
  const [store, setStore] = useState("");
  const [reviewData, setReviewData] = useState({ rating: 5, comment: "", productId: null });
  const [reviews, setReviews] = useState({});
  const [message, setMessage] = useState("");

  const API_BASE = "http://localhost:5000";

  const search = async () => {
    if (!query) return;
    const res = await fetch(`${API_BASE}/api/search?q=${query}`);
    const data = await res.json();
    setResults(data);

    const reviewMap = {};
    for (let item of data) {
      for (let alt of item.alternatives) {
        const r = await fetch(`${API_BASE}/api/reviews/${alt.id}`);
        reviewMap[alt.id] = await r.json();
      }
    }
    setReviews(reviewMap);
  };

  const suggest = async () => {
    if (!brand || !generic || !store) {
      setMessage("⚠️ All fields required.");
      return;
    }

    const res = await fetch(`${API_BASE}/api/suggest`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ brand, generic, store })
    });

    const data = await res.json();
    if (data.success) {
      setMessage("✅ Suggestion submitted!");
      setBrand(""); setGeneric(""); setStore("");
    } else {
      setMessage("❌ Failed to submit suggestion.");
    }
  };

  const submitReview = async () => {
    if (!reviewData.productId || !reviewData.rating) {
      setMessage("⚠️ Missing product or rating.");
      return;
    }

    const res = await fetch(`${API_BASE}/api/review`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(reviewData)
    });

    const data = await res.json();
    if (data.success) {
      setMessage("✅ Review submitted!");
      setReviewData({ rating: 5, comment: "", productId: null });
      search();
    } else {
      setMessage("❌ Failed to submit review.");
    }
  };

  const avgRating = (reviewsArr) => {
    if (!reviewsArr || reviewsArr.length === 0) return "No reviews yet";
    const avg = reviewsArr.reduce((sum, r) => sum + r.rating, 0) / reviewsArr.length;
    return `${avg.toFixed(1)} ⭐ (${reviewsArr.length} reviews)`;
  };

  return (
    <div style={{ padding: 20, fontFamily: "Arial, sans-serif" }}>
      <h1>Generic Food Finder 🍎</h1>
      <input value={query} onChange={e => setQuery(e.target.value)} placeholder="Enter a brand" />
      <button onClick={search}>Search</button>
      <div>{results.map(item => (
        <div key={item.brand}>
          <h3>{item.brand}</h3>
          <ul>
            {item.alternatives.map((alt) => (
              <li key={alt.id}>
                {alt.generic} ({alt.store}) <br />
                <strong>{avgRating(reviews[alt.id])}</strong>
                <button onClick={() => setReviewData({ ...reviewData, productId: alt.id, rating: 5, comment: "" })}>Leave Review</button>
              </li>
            ))}
          </ul>
        </div>
      ))}</div>
      <h2>Suggest</h2>
      <input value={brand} onChange={e => setBrand(e.target.value)} placeholder="Brand" />
      <input value={generic} onChange={e => setGeneric(e.target.value)} placeholder="Generic" />
      <input value={store} onChange={e => setStore(e.target.value)} placeholder="Store" />
      <button onClick={suggest}>Submit</button>
      {reviewData.productId && (
        <div>
          <h2>Leave Review</h2>
          <select value={reviewData.rating} onChange={e => setReviewData({ ...reviewData, rating: parseInt(e.target.value) })}>
            {[1,2,3,4,5].map(r => <option key={r} value={r}>{r} ⭐</option>)}
          </select>
          <textarea value={reviewData.comment} onChange={e => setReviewData({ ...reviewData, comment: e.target.value })} />
          <button onClick={submitReview}>Submit Review</button>
        </div>
      )}
      {message && <p>{message}</p>}
    </div>
  );
}

export default App;
