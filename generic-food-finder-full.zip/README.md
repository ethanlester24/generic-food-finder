# Generic Food Finder 🍎

Find cheaper **generic alternatives** to name-brand foods, suggest new products, and leave reviews.

## 🚀 How to Run Locally

### Backend
```bash
cd backend
npm install
npm start
```
Runs on `http://localhost:5000`

### Frontend
```bash
cd frontend
npm install
npm start
```
Runs on `http://localhost:3000`

## 🗄️ Database (Supabase)
Run this SQL in Supabase:
```sql
create table products (
  id serial primary key,
  brand_name text not null,
  generic_name text not null,
  store text not null
);

create table reviews (
  id serial primary key,
  product_id int references products(id) on delete cascade,
  rating int check (rating >= 1 and rating <= 5),
  comment text,
  created_at timestamp default now()
);
```

## 🌍 Deployment
- Push code to GitHub
- Backend → Render (point to `/backend`)
- Frontend → Netlify (point to `/frontend`)
