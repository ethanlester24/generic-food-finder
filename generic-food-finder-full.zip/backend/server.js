// backend/server.js
import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import { createClient } from "@supabase/supabase-js";

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);

app.get("/api/search", async (req, res) => {
  const q = req.query.q?.toLowerCase();
  if (!q) return res.json([]);

  const { data, error } = await supabase
    .from("products")
    .select("id, brand_name, generic_name, store")
    .ilike("brand_name", `%${q}%`);

  if (error) return res.status(500).json({ error: error.message });

  const grouped = {};
  data.forEach(item => {
    if (!grouped[item.brand_name]) grouped[item.brand_name] = [];
    grouped[item.brand_name].push({ id: item.id, generic: item.generic_name, store: item.store });
  });

  const results = Object.keys(grouped).map(brand => ({
    brand,
    alternatives: grouped[brand]
  }));

  res.json(results);
});

app.post("/api/suggest", async (req, res) => {
  const { brand, generic, store } = req.body;
  if (!brand || !generic || !store) return res.status(400).json({ error: "Missing fields" });

  const { data, error } = await supabase
    .from("products")
    .insert([{ brand_name: brand, generic_name: generic, store }]);

  if (error) return res.status(500).json({ error: error.message });

  res.json({ success: true, data });
});

app.post("/api/review", async (req, res) => {
  const { product_id, rating, comment } = req.body;
  if (!product_id || !rating) return res.status(400).json({ error: "Missing product_id or rating" });

  const { data, error } = await supabase
    .from("reviews")
    .insert([{ product_id, rating, comment }]);

  if (error) return res.status(500).json({ error: error.message });

  res.json({ success: true, data });
});

app.get("/api/reviews/:productId", async (req, res) => {
  const { productId } = req.params;

  const { data, error } = await supabase
    .from("reviews")
    .select("id, rating, comment, created_at")
    .eq("product_id", productId)
    .order("created_at", { ascending: false });

  if (error) return res.status(500).json({ error: error.message });

  res.json(data);
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`✅ Backend running on port ${PORT}`));
